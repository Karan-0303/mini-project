import { useState } from 'react';
import Login from './components/Login';
import CreateAccount from './components/CreateAccount';
import Dashboard from './components/Dashboard';

type AppView = 'login' | 'create' | 'dashboard';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('login');
  const [loggedInAccount, setLoggedInAccount] = useState<string | null>(null);

  const handleLogin = (accountNumber: string) => {
    setLoggedInAccount(accountNumber);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setLoggedInAccount(null);
    setCurrentView('login');
  };

  const navigateToCreate = () => {
    setCurrentView('create');
  };

  const navigateToLogin = () => {
    setCurrentView('login');
  };

  return (
    <div className="size-full">
      {currentView === 'login' && (
        <Login onLogin={handleLogin} onNavigateToCreate={navigateToCreate} />
      )}

      {currentView === 'create' && (
        <CreateAccount onNavigateToLogin={navigateToLogin} />
      )}

      {currentView === 'dashboard' && loggedInAccount && (
        <Dashboard accountNumber={loggedInAccount} onLogout={handleLogout} />
      )}
    </div>
  );
}