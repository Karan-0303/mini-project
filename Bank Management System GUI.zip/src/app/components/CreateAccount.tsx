import { useState } from 'react';
import { UserPlus, ArrowLeft, CheckCircle } from 'lucide-react';
import { loadData, saveData, generateAccountNumber, hashPin, isValidPhone, isValidPin, getTimestamp } from '../utils/bankData';

interface CreateAccountProps {
  onNavigateToLogin: () => void;
}

export default function CreateAccount({ onNavigateToLogin }: CreateAccountProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [initialDeposit, setInitialDeposit] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [newAccountNumber, setNewAccountNumber] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Validations
      if (!name.trim()) {
        setError('Name cannot be empty.');
        setLoading(false);
        return;
      }

      if (!isValidPhone(phone)) {
        setError('Please enter a valid 10-digit phone number.');
        setLoading(false);
        return;
      }

      if (!isValidPin(pin)) {
        setError('PIN must be exactly 4 digits.');
        setLoading(false);
        return;
      }

      if (pin !== confirmPin) {
        setError('PINs do not match. Please try again.');
        setLoading(false);
        return;
      }

      const depositAmount = parseFloat(initialDeposit);
      if (isNaN(depositAmount) || depositAmount < 500) {
        setError('Minimum initial deposit is ₹500.');
        setLoading(false);
        return;
      }

      // Create account
      const accountNumber = generateAccountNumber();
      const hashedPin = await hashPin(pin);
      const data = loadData();

      data[accountNumber] = {
        name: name.trim(),
        phone,
        pin: hashedPin,
        balance: depositAmount,
        created_on: getTimestamp(),
        transactions: [
          {
            type: 'Account Opened / Initial Deposit',
            amount: depositAmount,
            date: getTimestamp(),
            balance_after: depositAmount,
          },
        ],
      };

      saveData(data);
      setNewAccountNumber(accountNumber);
      setSuccess(true);
      setLoading(false);
    } catch (err) {
      setError('An error occurred. Please try again.');
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mb-4">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-2">Account Created Successfully!</h2>
            <p className="text-gray-600 mb-6">Your bank account is now active</p>

            <div className="bg-gray-50 rounded-lg p-6 mb-6 text-left">
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Account Holder</p>
                  <p className="font-semibold text-gray-900">{name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Account Number</p>
                  <p className="font-bold text-xl text-indigo-600">{newAccountNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Opening Balance</p>
                  <p className="font-semibold text-gray-900">₹{parseFloat(initialDeposit).toFixed(2)}</p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-yellow-800 font-medium">
                ⚠️ Please save your account number safely!
              </p>
            </div>

            <button
              onClick={onNavigateToLogin}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-lg transition"
            >
              Continue to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <button
          onClick={onNavigateToLogin}
          className="flex items-center gap-2 text-indigo-600 hover:text-indigo-700 font-medium mb-6 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Login
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">Create New Account</h2>
            <p className="text-gray-600 text-sm mt-1">Fill in your details to open a bank account</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Full Name
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="Enter your full name"
                required
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="Enter 10-digit phone number"
                maxLength={10}
                required
              />
            </div>

            <div>
              <label htmlFor="pin" className="block text-sm font-medium text-gray-700 mb-2">
                Set 4-Digit PIN
              </label>
              <input
                id="pin"
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="Enter 4-digit PIN"
                maxLength={4}
                required
              />
            </div>

            <div>
              <label htmlFor="confirmPin" className="block text-sm font-medium text-gray-700 mb-2">
                Confirm PIN
              </label>
              <input
                id="confirmPin"
                type="password"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="Re-enter 4-digit PIN"
                maxLength={4}
                required
              />
            </div>

            <div>
              <label htmlFor="initialDeposit" className="block text-sm font-medium text-gray-700 mb-2">
                Initial Deposit (₹)
              </label>
              <input
                id="initialDeposit"
                type="number"
                value={initialDeposit}
                onChange={(e) => setInitialDeposit(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="Minimum ₹500"
                min="500"
                step="0.01"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Minimum initial deposit is ₹500</p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-lg transition flex items-center justify-center gap-2"
            >
              <UserPlus className="w-5 h-5" />
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
