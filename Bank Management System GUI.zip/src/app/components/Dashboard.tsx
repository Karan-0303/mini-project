import { useState, useEffect } from 'react';
import {
  LogOut,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Send,
  History,
  Trash2,
  Eye,
  EyeOff
} from 'lucide-react';
import { loadData, saveData, hashPin, isValidAmount, getTimestamp, Account } from '../utils/bankData';

interface DashboardProps {
  accountNumber: string;
  onLogout: () => void;
}

type ModalType = 'deposit' | 'withdraw' | 'transfer' | 'history' | 'delete' | null;

export default function Dashboard({ accountNumber, onLogout }: DashboardProps) {
  const [account, setAccount] = useState<Account | null>(null);
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [amount, setAmount] = useState('');
  const [targetAccount, setTargetAccount] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [showBalance, setShowBalance] = useState(true);

  useEffect(() => {
    loadAccountData();
  }, [accountNumber]);

  const loadAccountData = () => {
    const data = loadData();
    if (data[accountNumber]) {
      setAccount(data[accountNumber]);
    }
  };

  const closeModal = () => {
    setActiveModal(null);
    setAmount('');
    setTargetAccount('');
    setPin('');
    setError('');
    setSuccess('');
    setLoading(false);
  };

  const handleDeposit = async () => {
    setError('');
    setSuccess('');
    setLoading(true);

    const depositAmount = parseFloat(amount);

    if (!isValidAmount(depositAmount)) {
      setError('Please enter a valid amount greater than 0.');
      setLoading(false);
      return;
    }

    const data = loadData();
    data[accountNumber].balance += depositAmount;
    data[accountNumber].transactions.push({
      type: 'Deposit',
      amount: depositAmount,
      date: getTimestamp(),
      balance_after: data[accountNumber].balance,
    });

    saveData(data);
    loadAccountData();
    setSuccess(`₹${depositAmount.toFixed(2)} deposited successfully!`);
    setAmount('');
    setLoading(false);

    setTimeout(() => {
      closeModal();
    }, 2000);
  };

  const handleWithdraw = async () => {
    setError('');
    setSuccess('');
    setLoading(true);

    const withdrawAmount = parseFloat(amount);

    if (!isValidAmount(withdrawAmount)) {
      setError('Please enter a valid amount greater than 0.');
      setLoading(false);
      return;
    }

    const data = loadData();
    const currentBalance = data[accountNumber].balance;

    if (withdrawAmount > currentBalance) {
      setError('Insufficient balance.');
      setLoading(false);
      return;
    }

    if (currentBalance - withdrawAmount < 500) {
      setError('Cannot withdraw. Minimum balance of ₹500 must be maintained.');
      setLoading(false);
      return;
    }

    data[accountNumber].balance -= withdrawAmount;
    data[accountNumber].transactions.push({
      type: 'Withdrawal',
      amount: withdrawAmount,
      date: getTimestamp(),
      balance_after: data[accountNumber].balance,
    });

    saveData(data);
    loadAccountData();
    setSuccess(`₹${withdrawAmount.toFixed(2)} withdrawn successfully!`);
    setAmount('');
    setLoading(false);

    setTimeout(() => {
      closeModal();
    }, 2000);
  };

  const handleTransfer = async () => {
    setError('');
    setSuccess('');
    setLoading(true);

    const transferAmount = parseFloat(amount);

    if (!isValidAmount(transferAmount)) {
      setError('Please enter a valid amount greater than 0.');
      setLoading(false);
      return;
    }

    if (targetAccount.length !== 10) {
      setError('Please enter a valid 10-digit account number.');
      setLoading(false);
      return;
    }

    const data = loadData();

    if (targetAccount === accountNumber) {
      setError('Cannot transfer to your own account.');
      setLoading(false);
      return;
    }

    if (!(targetAccount in data)) {
      setError('Recipient account not found.');
      setLoading(false);
      return;
    }

    const currentBalance = data[accountNumber].balance;

    if (transferAmount > currentBalance) {
      setError('Insufficient balance.');
      setLoading(false);
      return;
    }

    if (currentBalance - transferAmount < 500) {
      setError('Cannot transfer. Minimum balance of ₹500 must be maintained.');
      setLoading(false);
      return;
    }

    // Debit sender
    data[accountNumber].balance -= transferAmount;
    data[accountNumber].transactions.push({
      type: `Transfer to ${targetAccount}`,
      amount: transferAmount,
      date: getTimestamp(),
      balance_after: data[accountNumber].balance,
      to_account: targetAccount,
    });

    // Credit recipient
    data[targetAccount].balance += transferAmount;
    data[targetAccount].transactions.push({
      type: `Transfer from ${accountNumber}`,
      amount: transferAmount,
      date: getTimestamp(),
      balance_after: data[targetAccount].balance,
      from_account: accountNumber,
    });

    saveData(data);
    loadAccountData();
    setSuccess(`₹${transferAmount.toFixed(2)} transferred to ${data[targetAccount].name} successfully!`);
    setAmount('');
    setTargetAccount('');
    setLoading(false);

    setTimeout(() => {
      closeModal();
    }, 2000);
  };

  const handleDeleteAccount = async () => {
    setError('');
    setSuccess('');
    setLoading(true);

    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN.');
      setLoading(false);
      return;
    }

    const hashedPin = await hashPin(pin);
    const data = loadData();

    if (data[accountNumber].pin !== hashedPin) {
      setError('Incorrect PIN. Account NOT deleted.');
      setLoading(false);
      return;
    }

    delete data[accountNumber];
    saveData(data);
    alert('Account deleted successfully. You will be logged out.');
    onLogout();
  };

  if (!account) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Welcome, {account.name}!</h1>
              <p className="text-gray-600 text-sm">Account: {accountNumber}</p>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
            >
              <LogOut className="w-5 h-5" />
              Logout
            </button>
          </div>
        </div>

        {/* Balance Card */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl shadow-lg p-8 mb-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-100 mb-2">Available Balance</p>
              <div className="flex items-center gap-4">
                {showBalance ? (
                  <h2 className="text-4xl font-bold">₹{account.balance.toFixed(2)}</h2>
                ) : (
                  <h2 className="text-4xl font-bold">••••••</h2>
                )}
                <button
                  onClick={() => setShowBalance(!showBalance)}
                  className="p-2 hover:bg-white/20 rounded-lg transition"
                >
                  {showBalance ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <Wallet className="w-16 h-16 opacity-50" />
          </div>
          <p className="text-indigo-100 text-sm mt-4">Account since: {account.created_on}</p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
          <button
            onClick={() => setActiveModal('deposit')}
            className="bg-white hover:bg-gray-50 rounded-xl shadow p-6 transition flex flex-col items-center gap-3"
          >
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <ArrowDownCircle className="w-6 h-6 text-green-600" />
            </div>
            <span className="font-semibold text-gray-900">Deposit</span>
          </button>

          <button
            onClick={() => setActiveModal('withdraw')}
            className="bg-white hover:bg-gray-50 rounded-xl shadow p-6 transition flex flex-col items-center gap-3"
          >
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <ArrowUpCircle className="w-6 h-6 text-orange-600" />
            </div>
            <span className="font-semibold text-gray-900">Withdraw</span>
          </button>

          <button
            onClick={() => setActiveModal('transfer')}
            className="bg-white hover:bg-gray-50 rounded-xl shadow p-6 transition flex flex-col items-center gap-3"
          >
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Send className="w-6 h-6 text-blue-600" />
            </div>
            <span className="font-semibold text-gray-900">Transfer</span>
          </button>

          <button
            onClick={() => setActiveModal('history')}
            className="bg-white hover:bg-gray-50 rounded-xl shadow p-6 transition flex flex-col items-center gap-3"
          >
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <History className="w-6 h-6 text-purple-600" />
            </div>
            <span className="font-semibold text-gray-900">History</span>
          </button>

          <button
            onClick={() => setActiveModal('delete')}
            className="bg-white hover:bg-gray-50 rounded-xl shadow p-6 transition flex flex-col items-center gap-3"
          >
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <span className="font-semibold text-gray-900">Delete</span>
          </button>
        </div>

        {/* Recent Transactions */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Transactions</h3>
          {account.transactions.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No transactions yet</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Type</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Amount</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Balance</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {account.transactions.slice(-10).reverse().map((txn, idx) => (
                    <tr key={idx} className="border-b last:border-0 hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm">{txn.type}</td>
                      <td className={`py-3 px-4 text-sm text-right font-semibold ${
                        txn.type.includes('Deposit') || txn.type.includes('from')
                          ? 'text-green-600'
                          : 'text-red-600'
                      }`}>
                        {txn.type.includes('Deposit') || txn.type.includes('from') ? '+' : '-'}₹{txn.amount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-sm text-right">₹{txn.balance_after.toFixed(2)}</td>
                      <td className="py-3 px-4 text-sm text-right text-gray-600">{txn.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {activeModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={closeModal}>
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
            {/* Deposit Modal */}
            {activeModal === 'deposit' && (
              <>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Deposit Money</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Amount (₹)</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                  </div>

                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}
                  {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">{success}</div>}

                  <div className="flex gap-3">
                    <button
                      onClick={closeModal}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDeposit}
                      disabled={loading || !amount}
                      className="flex-1 px-4 py-3 bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white rounded-lg transition"
                    >
                      {loading ? 'Processing...' : 'Deposit'}
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* Withdraw Modal */}
            {activeModal === 'withdraw' && (
              <>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Withdraw Money</h3>
                <div className="space-y-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-900">Available Balance: <span className="font-bold">₹{account.balance.toFixed(2)}</span></p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Amount (₹)</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                    <p className="text-xs text-gray-500 mt-1">Minimum balance of ₹500 must be maintained</p>
                  </div>

                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}
                  {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">{success}</div>}

                  <div className="flex gap-3">
                    <button
                      onClick={closeModal}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleWithdraw}
                      disabled={loading || !amount}
                      className="flex-1 px-4 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-300 text-white rounded-lg transition"
                    >
                      {loading ? 'Processing...' : 'Withdraw'}
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* Transfer Modal */}
            {activeModal === 'transfer' && (
              <>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Transfer Money</h3>
                <div className="space-y-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-900">Available Balance: <span className="font-bold">₹{account.balance.toFixed(2)}</span></p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Recipient Account Number</label>
                    <input
                      type="text"
                      value={targetAccount}
                      onChange={(e) => setTargetAccount(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Enter 10-digit account number"
                      maxLength={10}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Amount (₹)</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                    <p className="text-xs text-gray-500 mt-1">Minimum balance of ₹500 must be maintained</p>
                  </div>

                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}
                  {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">{success}</div>}

                  <div className="flex gap-3">
                    <button
                      onClick={closeModal}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleTransfer}
                      disabled={loading || !amount || !targetAccount}
                      className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white rounded-lg transition"
                    >
                      {loading ? 'Processing...' : 'Transfer'}
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* History Modal */}
            {activeModal === 'history' && (
              <>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Transaction History</h3>
                <div className="max-h-96 overflow-y-auto">
                  {account.transactions.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No transactions yet</p>
                  ) : (
                    <div className="space-y-3">
                      {account.transactions.slice().reverse().map((txn, idx) => (
                        <div key={idx} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <span className="font-medium text-gray-900">{txn.type}</span>
                            <span className={`font-bold ${
                              txn.type.includes('Deposit') || txn.type.includes('from')
                                ? 'text-green-600'
                                : 'text-red-600'
                            }`}>
                              {txn.type.includes('Deposit') || txn.type.includes('from') ? '+' : '-'}₹{txn.amount.toFixed(2)}
                            </span>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Balance: ₹{txn.balance_after.toFixed(2)}</p>
                            <p>{txn.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  onClick={closeModal}
                  className="w-full mt-4 px-4 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition"
                >
                  Close
                </button>
              </>
            )}

            {/* Delete Modal */}
            {activeModal === 'delete' && (
              <>
                <h3 className="text-xl font-bold text-red-600 mb-4">Delete Account</h3>
                <div className="space-y-4">
                  <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                    <p className="text-sm text-red-800 font-medium">⚠️ Warning: This action is permanent!</p>
                    <p className="text-sm text-red-700 mt-1">Your account and all transaction history will be deleted.</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Enter your PIN to confirm</label>
                    <input
                      type="password"
                      value={pin}
                      onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
                      placeholder="Enter 4-digit PIN"
                      maxLength={4}
                    />
                  </div>

                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}

                  <div className="flex gap-3">
                    <button
                      onClick={closeModal}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDeleteAccount}
                      disabled={loading || pin.length !== 4}
                      className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 disabled:bg-gray-300 text-white rounded-lg transition"
                    >
                      {loading ? 'Deleting...' : 'Delete Account'}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
