// Bank Data Management with LocalStorage
// Mirrors the Python JSON file storage approach

export interface Transaction {
  type: string;
  amount: number;
  date: string;
  balance_after: number;
  from_account?: string;
  to_account?: string;
}

export interface Account {
  name: string;
  phone: string;
  pin: string; // SHA-256 hashed
  balance: number;
  created_on: string;
  transactions: Transaction[];
}

export interface BankData {
  [accountNumber: string]: Account;
}

const STORAGE_KEY = 'bank_data';

// Hash PIN using SHA-256
export async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

// Load all accounts from LocalStorage
export function loadData(): BankData {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Error loading bank data:', error);
    return {};
  }
}

// Save all accounts to LocalStorage
export function saveData(data: BankData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving bank data:', error);
  }
}

// Generate unique 10-digit account number
export function generateAccountNumber(): string {
  const data = loadData();
  let accountNumber: string;

  do {
    accountNumber = Math.floor(1000000000 + Math.random() * 9000000000).toString();
  } while (accountNumber in data);

  return accountNumber;
}

// Get current timestamp
export function getTimestamp(): string {
  const now = new Date();
  return now.toLocaleString('en-IN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
}

// Validate phone number (10 digits)
export function isValidPhone(phone: string): boolean {
  return /^\d{10}$/.test(phone);
}

// Validate PIN (4 digits)
export function isValidPin(pin: string): boolean {
  return /^\d{4}$/.test(pin);
}

// Validate amount (positive number)
export function isValidAmount(amount: number): boolean {
  return !isNaN(amount) && amount > 0;
}
